from read import file_read
from datetime import datetime

def purchase_Laptop():
    
    print("\n")
    print("-------------------------------------------------------------------------------------------------------------------------------------")
    print("-------------------------------------------------------------------------------------------------------------------------------------")
    print("We will need your name and number to print the bill.")
    print("-------------------------------------------------------------------------------------------------------------------------------------")
    print("-------------------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    name = input("Enter your name :")
    phone = input("Enter your phone :")
    print("-------------------------------------------------------------------------------------------------------------------------------------")
    print("-------------------------------------------------------------------------------------------------------------------------------------")
    print("S.N \t  Name \t \t Brand \t \t Price \t \t  Quantity \t  Processor \t  Graphic card")
    print("-------------------------------------------------------------------------------------------------------------------------------------")
    print("-------------------------------------------------------------------------------------------------------------------------------------")
    a = 1
    file = open("Laptop.txt", "r")
    for line in file:
        print(a, "\t" + line.replace(",", "\t"))
        a = a + 1
    print("------------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------------")
    file.close()
    print("\n")

    Id_valid = int(input("Please provide the ID of the laptop you want to buy : "))
    print("\n")

    #Valid Id

    while Id_valid <= 0 or Id_valid > len(file_read()):
        print("Please provide a valid Laptop Id !!!")
        print("\n")
        Id_valid = int(input("Please provide the ID of the laptop you want to buy :"))
    Quantity_user = int(input("Please provide the number of laptops you want to buy :"))
    print("\n")


    # valid quantity

    Laptop_Dictionary = file_read()
    quantity_get = Laptop_Dictionary[Id_valid][3]
    while Quantity_user <= 0 or Quantity_user > int(quantity_get):
        print("The quantity you are looking for is not available in our shop.")
        print("\n")
        Quantity_user = int(input("Please provide the number of laptops you want to buy :"))
    print("\n")

    # update the text file

    Laptop_Dictionary[Id_valid][3] = int(Laptop_Dictionary[Id_valid][3]) + int(Quantity_user)

    file = open("Laptop.txt", "w")

    for values in Laptop_Dictionary.values():
        file.write(str(values[0]) + "," + str(values[1]) + "," + str(values[2]) + "," + str(values[3]) + "," + str(values[4]) + "," + str(values[5]))
        file.write("\n")
    file.close()

    #Purchasing from the manufacturer

    name_of_product = Laptop_Dictionary[Id_valid][0]
    name_of_brand = Laptop_Dictionary[Id_valid][1]
    quantity_of_user = Quantity_user
    unit_price = Laptop_Dictionary[Id_valid][2].replace("$", "")
    final_price = int(unit_price) * int(quantity_of_user)
    
    Laptop_purchased = []
    Laptop_purchased.append([name_of_product, name_of_brand, quantity_of_user, unit_price, final_price ])
    total_final = 0
    total_final = total_final + final_price
    

    loop_buy = True
    while loop_buy == True:
        buy = input("Do you want to buy more laptops ? (y/n) :")
        if buy == "y" or buy == "Y":

            #valid ID

            while Id_valid <= 0 or Id_valid > len(file_read()):
                print("Please provide a valid laptop Id !!!")
                print("\n")
            Id_valid = int(input("Please provide the ID of the laptop you want to buy :"))
            Quantity_user = int(input("Please provide the number of laptops you want to buy :"))
            print("\n")

            #valid quantity

            Laptop_Dictionary = file_read()
            quantity_get = Laptop_Dictionary[Id_valid][3]
            while Quantity_user <= 0 or Quantity_user > int(quantity_get):
                print("The quantity you are looking for is not avaialble in our shop.")
                print("\n")
                Quantity_user = int(input("Please provide the number of laptops you want to buy :"))
            print("\n")

            #update the text file

            Laptop_Dictionary[Id_valid][3] = int(Laptop_Dictionary[Id_valid][3]) + int(Quantity_user)
                
            file = open("Laptop.txt", "w")

            for values in Laptop_Dictionary.values():
                file.write(str(values[0]) + "," + str(values[1]) + "," + str(values[2]) + "," + str(values[3]) + "," + str(values[4]) + "," + str(values[5]))
                file.write("\n")
            file.close()

            #purchasing from manufacturer

                
            name_of_product = Laptop_Dictionary[Id_valid][0]
            name_of_brand = Laptop_Dictionary[Id_valid][1]
            quantity_of_user = Quantity_user
            unit_price = Laptop_Dictionary[Id_valid][2].replace("$", "")
            final_price = int(unit_price) * int(quantity_of_user)

            total_final = total_final + final_price
            VAT = 0.13 * total_final
            total_with_VAT = VAT + total_final
                

            Laptop_purchased.append([name_of_product, name_of_brand, quantity_of_user, unit_price, final_price ])
                 
        else:

            loop_buy = False
    name_of_product = Laptop_Dictionary[Id_valid][0]
    name_of_brand = Laptop_Dictionary[Id_valid][1]
    quantity_of_user = Quantity_user
    unit_price = Laptop_Dictionary[Id_valid][2].replace("$", "")
    final_price = int(unit_price) * int(quantity_of_user)

    total_final = total_final + final_price
    VAT = 0.13 * total_final
    total_with_VAT = VAT + total_final
                

    Laptop_purchased.append([name_of_product, name_of_brand, quantity_of_user, unit_price, final_price ])

    time_and_date = datetime.now()
    print("\n")
    print("\t \t \t \t Our Laptop Shop.")
    print("\n")
    print("\t \t Gwarko, Lalitpur | Phone No: 9827557766")
    print("\n")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("Laptop Details :")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("Customer Name :" + str(name))
    print("Phone Number :" + str(phone))
    print("Date and Time :" + str(time_and_date))
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("Purchase Details are :")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("Product Name \t  Brand \t Total Quantity \t\t Unit Price \t Total")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")

    for i in Laptop_purchased:
        print(i[0], "\t", i[1], "\t", i[2], "\t\t\t", i[3], "\t\t", "$", i[4])
            
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")

    print("Vat Amount :", VAT)
    print("Grand Total :" + str(total_with_VAT))
    print("**Note : Vat amount was added to grand total.")
    print("Thank you for buying !!!")

        
    return name,phone,time_and_date,Laptop_purchased,VAT,total_final,total_with_VAT




def sale_Laptop():
    print("Thank you for selling")
    print("\n")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("We will need your name and number to print the bill.")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    name = input("Enter your name :")
    phone = input("Enter your phone :")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("S.N \t \t Name \t \t Brand \t \t Price \t \t Quantity  \t Processor  \t Graphic card")
    print("------------------------------------------------------------------------------------------------------------------------------")
    print("------------------------------------------------------------------------------------------------------------------------------")
    a = 1
    file = open("Laptop.txt", "r")
    for line in file:
        print(a, "\t" + line.replace(",", "\t"))
        a = a + 1
    print("-----------------------------------------------------------------------------------------------------------------------------")
    print("-----------------------------------------------------------------------------------------------------------------------------")
    file.close()
    print("\n")

    Id_valid = int(input("Please provide the ID of the laptop you want to sell : "))
    print("\n")

    #Valid Id

    while Id_valid <= 0 and Id_valid > len(file_read()):
        print("Please provide a valid Laptop Id !!!")
        print("\n")
    Id_valid = int(input("Please provide the ID of the laptop you want to sell :")) 
    Quantity_user = int(input("Please provide the number of laptops you want to sell :"))
    print("\n")


    # valid quantity

    Laptop_Dictionary = file_read()
    quantity_get = Laptop_Dictionary[Id_valid][3]
    while Quantity_user <= 0 or Quantity_user > int(quantity_get):
        print("The quantity you are looking for is not available in our shop.")
        print("\n")
        Quantity_user = int(input("Please provide the number of laptops you want to sell :"))
    print("\n")

    # update the text file

    Laptop_Dictionary[Id_valid][3] = int(Laptop_Dictionary[Id_valid][3]) + int(Quantity_user)

    file = open("Laptop.txt", "w")

    for values in Laptop_Dictionary.values():
        file.write(str(values[0]) + "," + str(values[1]) + "," + str(values[2]) + "," + str(values[3]) + "," + str(values[4]) + "," + str(values[5]))
        file.write("\n")
    file.close()

    #Purchasing from the manufacturer

    name_of_product = Laptop_Dictionary[Id_valid][0]
    name_of_brand = Laptop_Dictionary[Id_valid][1]
    quantity_of_user = Quantity_user
    unit_price = Laptop_Dictionary[Id_valid][2].replace("$", "")
    final_price = int(unit_price) * int(quantity_of_user)
    Laptop_purchased = []
    Laptop_purchased.append([name_of_product, name_of_brand, quantity_of_user, unit_price, final_price ])
    total_final = 0
    total_final = total_final + final_price

    loop_sell = True
    while loop_sell == True:
        continue_sell = input("Doy you want to buy more laptops ? (y/n) ").lower()
        if continue_sell == "y":
            Id_valid = int(input("Please provide the ID of the laptop you want to sell :"))
            print("\n")

            #valid id

            while Id_valid <= 0 or Id_valid > len(file_read()):
                print("Please provide a valid laptop Id!!!")
                print("\n")
            Id_valid = int(input("Please provide the ID of the laptop you want to sell :"))
            Quantity_user = int(input("Please provide the number of laptop you want to sell :"))
            print("\n")

            #valid quantity

            Laptop_Dictionary = file_read()
            quantity_get = Laptop_Dictionary[Id_valid][3]

            while Quantity_user <= 0 or Quantity_user > int(quantity_get):
                print("The quantity you are looking for is not available.")
                print("\n")
                Quantity_user = int(input("Please provide the number of laptop you want to sell :"))
            print("\n")

            #update the text file

            Laptop_Dictionary[Id_valid][3] = int(Laptop_Dictionary[Id_valid][3]) - int(Quantity_user)

            file = open("Laptop.txt", "w")

            for values in Laptop_Dictionary.values():
                file.write(str(values[0]) + "," + str(values[1]) + "," + str(values[2]) + "," + str(values[3]) + "," + str(values[4]) + "," + str(values[5]))
                file.write("\n")
            file.close()

            #getting user purchased items

            name_of_product = Laptop_Dictionary[Id_valid][0]
            name_of_brand = Laptop_Dictionary[Id_valid][1]
            quantity_of_user = Quantity_user
            item_price = Laptop_Dictionary[Id_valid][2].replace("$", '')
            final_price = int(item_price) * int(quantity_of_user)
            

            Laptop_purchased.append([name_of_product,name_of_brand,quantity_of_user,item_price,final_price])
            total_final = total_final + final_price
        else:
            loop_sell = False

    time_and_date = datetime.now()
    shipping_cost = input("Do you want your laptop to be shipped? (Y/N)")

    print("\n")
    print("\t \t \t \t Our Laptop Shop")
    print("\n")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("\t \t Gwarko, Lalitpur | Phone No : 9827557766")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("Laptop Details :")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("Customer Name :" + str(name))
    print("Phone Number :" + str(phone))
    print("Date and Time :" + str(time_and_date))
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    print("Purchase Details are :")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("Product Name \t Brand \t Total Quantity \t Unit Price \t Total")
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("----------------------------------------------------------------------------------------------------------------------------")

    for i in Laptop_purchased:
        print(i[0], "\t", i[1], "\t", i[2], "\t\t\t", i[3], "\t\t", "$", i[4])
    print("----------------------------------------------------------------------------------------------------------------------------")
    print("----------------------------------------------------------------------------------------------------------------------------")

    if shipping_cost == "Y" or shipping_cost == "y":
        total = 0
        shipping_cost = 700

        for i in Laptop_purchased:
            total += int(i[4])
        total_final = total + shipping_cost
        print("Shipping Cost :", shipping_cost)
        print("Grand Total :" + str (total_final))
        print("Note : Shipping cost is added to the grand total.")
        print("Thank you for selling")
    else:
        total = 0
        shipping_cost = 0

        for i in Laptop_purchased:
            total += int(i[4])
        total_final = total + shipping_cost
        print("Grand Total :" + str(total_final))

    return name,phone,time_and_date,Laptop_purchased,shipping_cost,total_final

    
            
        
            
        


        
    
    
    
    
    

    

    
            
                
                




            

            
                
                
            
        
        

    


        
    
         


    
