def write_sold(name,phone,date_and_time,Laptop_purchased,shipping_cost,total_final):
    with open(str(name) + str(phone) + ".txt", "w") as file:
        file.write("\n")
        file.write("\t\t\t Our Laptop Shop")
        file.write("\n")
        file.write("\t\t Gwarko, Lalitpur | Phone No: 9827557766")
        file.write("\n")
        file.write("----------------------------------------------------------------------------------------------------------")
        file.write("----------------------------------------------------------------------------------------------------------")
        file.write("\n")
        file.write("Laptop Details :")
        file.write("\n")
        file.write("----------------------------------------------------------------------------------------------------------")
        file.write("----------------------------------------------------------------------------------------------------------")
        file.write("Customer Name :" + str(name))
        file.write("\n")
        file.write("Phone Number :" + str(phone))
        file.write("\n")
        file.write("Date and Time :" + str(date_and_time))
        file.write("\n")
        file.write("-----------------------------------------------------------------------------------------------------------")
        file.write("-----------------------------------------------------------------------------------------------------------")
        file.write("\n")
        file.write("Purchase Details are :")
        file.write("\n")
        file.write("------------------------------------------------------------------------------------------------------------")
        file.write("------------------------------------------------------------------------------------------------------------")
        file.write("Product Name \t\t Brand \t\t Total Quantity \t\t Unit Price \t Total")
        file.write("\n")
        file.write("------------------------------------------------------------------------------------------------------------")
        file.write("------------------------------------------------------------------------------------------------------------")

        for i in Laptop_purchased:
            file.write(str(i[0]) + "\t" + str(i[1]) + "\t\t" + str(i[2]) + "\t\t\t\t" + str(i[3]) + "\t\t" + "$" + str(i[4]) + "\n")
        file.write("------------------------------------------------------------------------------------------------------------")
        file.write("------------------------------------------------------------------------------------------------------------")
        file.write("\n")

        if shipping_cost == 700:
            file.write("Shipping Cost :" + "" + str (shipping_cost) + "\n")
            file.write("\n")
            file.write("Grand Total : $" + str(total_final) + "\n")
            file.write("\n")
            file.write("Note : Shipping cost is added to the grand total" + "\n")
        else:
            file.write("Grand Total : $" + str(total_final))




def write_purchase(name,phone,date_and_time,Laptop_purchased,VAT,total_final,total_with_VAT):
    with open(str(name) + str(phone) + ".txt", "w") as file:
        file.write("\n")
        file.write("\t\t\t Our Laptop Shop")
        file.write("\n")
        file.write("\t\t Gwarko, Lalitpur | Phone No: 9827557766")
        file.write("\n")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("\n")
        file.write("Laptop Details :")
        file.write("\n")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("Customer Name :" + str(name))
        file.write("\n")
        file.write("Phone Number :" + str(phone))
        file.write("\n")
        file.write("Date and Time :" + str(date_and_time))
        file.write("\n")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("\n")
        file.write("Purchase Details are :")
        file.write("\n")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("Product Name \t\t Brand \t\t Total Quantity \t\t Unit Price \t Total")
        file.write("\n")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("----------------------------------------------------------------------------------------------------------------")

        for i in Laptop_purchased:
            file.write(str(i[0]) + "\t" + str(i[1]) + "\t\t" + str(i[2]) + "\t\t\t\t"+ str(i[3]) + "\t\t" + "$" + str(i[4]) + "\n")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("----------------------------------------------------------------------------------------------------------------")
        file.write("\n")
        file.write("Vat Amount :" + "" + str(VAT) + "\n")
        file.write("\n")
        file.write("Grand Total : $" + str(total_with_VAT) + "\n")
        file.write("\n")
        file.write("Note : Vat amount has been added to the grand total." + "\n")
        file.write("\n")
        
        
        
    
        
            
            
        
        
