def file_read():
    file = open("Laptop.txt", "r")
    Id_of_Laptop = 1
    Laptop_Dictionary = {}
    for line in file:
        line = line.replace("\n", "")
        Laptop_Dictionary[Id_of_Laptop] = (line.split(","))
        Id_of_Laptop += 1
    file.close()
    return Laptop_Dictionary

        
