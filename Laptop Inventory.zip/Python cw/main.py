from operation import *
from write import *

print("\n")
print("----------------------------------------------------------------------------")
print("----------------------------------------------------------------------------")
print("\t \t ****Welcome to Our Laptop Shop****")
print("----------------------------------------------------------------------------")
print("----------------------------------------------------------------------------")
print("\t \t ****Address : Gwarko, Lalitpur | Contact No: 9827557766")
print("----------------------------------------------------------------------------")
print("----------------------------------------------------------------------------")
print("\n")

continueLoop = True
while continueLoop == True:
    print("\n")
    print("Press 1 : To buy from manufacturer.")
    print("Press 2 : To sell to customers.")
    print("Press 3 : To Exit.")
    print("\n")
    print("----------------------------------------------------------------------------")
    print("----------------------------------------------------------------------------")

    u_input = 0
    try:
        u_input = int(input("Press 1, 2 or 3 :"))
        print("\n")
        Opt = False
    except:
        print("Invalid !!! \nPlease input 1, 2 or 3 only.")

    if u_input == 1:
        name,phone,date_and_time,Laptop_purchased,VAT,total_final,total_with_VAT = purchase_Laptop()
        write_purchase(name,phone,date_and_time,Laptop_purchased,VAT,total_final,total_with_VAT)

    elif u_input == 2:
        name,phone,date_and_time,Laptop_purchased,shipping_cost,total_final = sale_Laptop()
        write_sold(name,phone,date_and_time,Laptop_purchased,shipping_cost,total_final)

    elif u_input == 3:
        continueLoop = False
        print("Thank you for visiting our shop.")
    else:
        print("Enter correct option.")
        

    
        
        
        
